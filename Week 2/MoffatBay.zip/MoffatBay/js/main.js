const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");

menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("is-open");
    menuToggle.setAttribute("aria-expanded", isOpen);
    menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Close navigation menu" : "Open navigation menu"
    );
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
        mainNav.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");
    }
});

window.addEventListener("resize", () => {
    if (window.innerWidth > 900) {
        mainNav.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");
    }
});

document.addEventListener("click", (event) => {
    if (
        mainNav.classList.contains("is-open") &&
        !event.target.closest(".site-header")
    ) {
        mainNav.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");
    }
});


/* ========================================
   ROOM DETAILS POPUP
======================================== */

const rooms = {
    morel: {
        name: "The Morel the Merrier",
        type: "Double Full Beds",
        image: "images/room-double-full.png",
        alt: "Cozy lodge room featuring two full beds",
        description: "Inspired by the quiet beauty of the forest floor, this cozy retreat brings together warm wood tones and natural textures for a restful island escape.",
        beds: "2 Full Beds",
        guests: "Up to 4 Guests",
        size: "300 sq. ft.",
        price: "$120 / night"
    },

    pine: {
        name: "The Knotty Pine",
        type: "Queen",
        image: "images/room-queen.png",
        alt: "Comfortable queen room with a cozy bedspread",
        description: "Inspired by the warmth of reclaimed pine timber, this inviting room combines rustic textures and soft comforts for a peaceful stay surrounded by nature.",
        beds: "1 Queen Bed",
        guests: "Up to 2 Guests",
        size: "260 sq. ft.",
        price: "$135 / night"
    },

    hoots: {
        name: "The Two Hoots",
        type: "Double Queen Beds",
        image: "images/room-double-queen.png",
        alt: "Spacious lodge room featuring two queen beds",
        description: "Named for the owls that call the island home, this spacious retreat offers a cozy place to gather, unwind, and enjoy the quiet magic of the forest.",
        beds: "2 Queen Beds",
        guests: "Up to 4 Guests",
        size: "380 sq. ft.",
        price: "$150 / night"
    },

    suite: {
        name: "The Unbe-leaf-able Suite",
        type: "King",
        image: "images/room-king.png",
        alt: "Rustic lodge suite featuring a king bed",
        description: "Inspired by the island's evergreen canopy, this spacious suite blends natural elegance with luxurious comfort for a truly relaxing getaway.",
        beds: "1 King Bed",
        guests: "Up to 2 Guests",
        size: "340 sq. ft.",
        price: "$160 / night"
    }
};

const roomModal = document.querySelector("#room-modal");
const roomButtons = document.querySelectorAll(".room-details-btn");
const closeRoomModal = document.querySelector(".room-modal-close");

// open the popup when view details is clicked

roomButtons.forEach((button) => {
    button.addEventListener("click", () => {

        // find which room was clicked
        const roomId = button.dataset.room;
        const room = rooms[roomId];

        if (!room) return;

        // update the popup with that room's information
        document.querySelector("#modal-room-name").textContent = room.name;
        document.querySelector("#modal-room-type").textContent = room.type;
        document.querySelector("#modal-room-description").textContent = room.description;
        document.querySelector("#modal-room-beds").textContent = room.beds;
        document.querySelector("#modal-room-guests").textContent = room.guests;
        document.querySelector("#modal-room-size").textContent = room.size;
        document.querySelector("#modal-room-price").textContent = room.price;

        // update the room photo
        const roomImage = document.querySelector("#modal-room-image");
        roomImage.src = room.image;
        roomImage.alt = room.alt;

        // open the popup
        roomModal.showModal();
    });
});


closeRoomModal.addEventListener("click", () => {
    roomModal.close();
});


roomModal.addEventListener("click", (event) => {
    if (event.target === roomModal) {
        roomModal.close();
    }
});
