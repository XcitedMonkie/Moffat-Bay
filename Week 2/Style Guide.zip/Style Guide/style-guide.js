const toast = document.querySelector('#toast');
let toastTimeout;
async function copyText(value) {
  try {
    await navigator.clipboard.writeText(value);
    toast.textContent = 'Copied to clipboard!';
  } catch {
    // Clipboard API can be restricted on local file:// pages.
    const helper = document.createElement('textarea');
    helper.value = value;
    helper.style.position = 'fixed';
    helper.style.opacity = '0';
    document.body.appendChild(helper);
    helper.select();
    const success = document.execCommand('copy');
    helper.remove();
    toast.textContent = success ? 'Copied to clipboard!' : 'Copy unavailable — select the text manually.';
  }
  toast.classList.add('visible');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('visible'), 2300);
}
document.querySelectorAll('[data-copy]').forEach(button => {
  button.addEventListener('click', () => copyText(button.dataset.copy));
});
document.querySelectorAll('[data-copy-target]').forEach(button => {
  button.addEventListener('click', () => copyText(document.getElementById(button.dataset.copyTarget).innerText));
});

const guideModal=document.querySelector('#guide-room-modal');
document.querySelectorAll('[data-open-guide-modal]').forEach(b=>b.addEventListener('click',()=>guideModal.showModal()));
document.querySelectorAll('[data-close-guide-modal]').forEach(b=>b.addEventListener('click',()=>guideModal.close()));
guideModal.addEventListener('click',e=>{if(e.target===guideModal)guideModal.close()});
